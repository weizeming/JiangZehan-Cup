python setup.py build && python setup.py install 
